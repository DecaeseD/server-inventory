(function () {
  var meta = JSON.parse(document.getElementById("ops-meta").textContent);
  var box = document.getElementById("lines");
  var total = document.getElementById("id_form-TOTAL_FORMS");
  var tpl = document.getElementById("line-template").innerHTML;

  function refresh(line) {
    var op = line.querySelector("select[name$='-operation']").value;
    var m = meta[op] || {};
    [["from_location", m.from], ["to_location", m.to], ["server", m.server]].forEach(function (p) {
      var f = line.querySelector(".f-" + p[0]);
      if (!f) return;
      f.classList.toggle("hide", !p[1]);
      if (!p[1]) { var s = f.querySelector("select"); if (s) s.value = ""; }
    });
  }
  function autoQty(line) {
    var ser = line.querySelector("textarea[name$='-serials']").value
      .split(/[\n,،]+/).filter(function (x) { return x.trim(); });
    if (ser.length) line.querySelector("input[name$='-quantity']").value = ser.length;
  }
  function wire(line) {
    line.querySelector("select[name$='-operation']").addEventListener("change", function () { refresh(line); });
    line.querySelector("textarea[name$='-serials']").addEventListener("input", function () { autoQty(line); });
    var rm = line.querySelector(".rm");
    if (rm) rm.addEventListener("click", function () {
      if (box.querySelectorAll(".line").length > 1) { line.remove(); renumber(); }
    });
    refresh(line);
  }
  function renumber() {
    var lines = box.querySelectorAll(".line");
    lines.forEach(function (l, i) {
      l.querySelectorAll("[name],[id],label[for]").forEach(function (el) {
        ["name", "id", "for"].forEach(function (a) {
          var v = el.getAttribute(a);
          if (v) el.setAttribute(a, v.replace(/form-\d+-/, "form-" + i + "-"));
        });
      });
      l.querySelector(".ln").textContent = i + 1;
    });
    total.value = lines.length;
  }
  document.getElementById("add-line").addEventListener("click", function () {
    var div = document.createElement("div");
    div.innerHTML = tpl.replace(/__prefix__/g, total.value);
    var line = div.firstElementChild;
    box.appendChild(line);
    wire(line); renumber();
  });
  box.querySelectorAll(".line").forEach(wire);
  renumber();
  var f = document.getElementById("req-form"), sent = false;
  f.addEventListener("submit", function (e) {
    if (sent) { e.preventDefault(); return; }
    sent = true; f.querySelector("button[type=submit]").disabled = true;
    f.querySelector("button[type=submit]").textContent = "در حال ثبت...";
  });
})();
